const BLOCKED = [
  { name: "TikTok", test: (url) => /(^|\.)tiktok\.com$/.test(url.hostname) },
  { name: "YouTube Shorts", test: (url) => url.hostname.endsWith("youtube.com") && url.pathname.startsWith("/shorts") },
  { name: "Instagram Reels", test: (url) => url.hostname.endsWith("instagram.com") && /^\/reels?(\/|$)/.test(url.pathname) }
];

function blockedName(rawUrl) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch (error) {
    console.warn("Cure Brainrot: cannot read URL", rawUrl, error);
    return null;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return null;
  const hit = BLOCKED.find((site) => site.test(url));
  return hit ? hit.name : null;
}
