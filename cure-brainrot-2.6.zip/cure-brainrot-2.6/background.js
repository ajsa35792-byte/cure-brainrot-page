importScripts("sites.js", "state.js");

const END_ALARM = "cureBrainrotEnd";

function remainingMs(state, now = Date.now()) {
  const limit = totalSeconds(state) * 1000;
  if (!state.countingSince) return Math.max(0, limit - state.seconds * 1000);
  return Math.max(0, limit - (state.seconds * 1000 + (now - state.countingSince)));
}

async function scheduleEnd() {
  const state = await loadState();
  await chrome.alarms.clear(END_ALARM);
  if (!state.countingSince) return;
  const left = remainingMs(state);
  chrome.alarms.create(END_ALARM, { when: Date.now() + Math.max(0, left) });
}

async function countClose(count) {
  const state = await loadState();
  state.tabsClosed = (state.tabsClosed || 0) + count;
  await saveState(state);
}

function closeTab(tabId) {
  return chrome.tabs.remove(tabId).then(
    () => true,
    (error) => {
      console.warn("Cure Brainrot: could not close tab", tabId, error.message);
      return false;
    }
  );
}

async function closeAllBlocked() {
  const tabs = await chrome.tabs.query({});
  let closed = 0;
  for (const tab of tabs) {
    if (tab.url && blockedName(tab.url) && (await closeTab(tab.id))) closed += 1;
  }
  if (closed) await countClose(closed);
  return closed;
}

let popupOpen = 0;

async function blockedTabInFront() {
  const win = await chrome.windows.getLastFocused({ populate: true });
  if (!win) return null;
  if (!win.focused && !popupOpen) return null;
  const tab = (win.tabs || []).find((item) => item.active);
  if (tab && tab.url && blockedName(tab.url)) return tab;
  if (popupOpen) {
    const all = await chrome.windows.getAll({ populate: true });
    for (const item of all) {
      const active = (item.tabs || []).find((t) => t.active);
      if (active && active.url && blockedName(active.url)) return active;
    }
  }
  return null;
}

async function startCounting() {
  await loadLimit();
  const state = await loadState();
  if (state.countingSince) return;
  state.countingSince = Date.now();
  await saveState(state);
  await scheduleEnd();
}

async function stopCounting() {
  await loadLimit();
  const state = await loadState();
  if (!state.countingSince) return;
  const now = Date.now();
  state.seconds = Math.min(totalSeconds(state), state.seconds + Math.round((now - state.countingSince) / 1000));
  state.countingSince = 0;
  await saveState(state);
  await chrome.alarms.clear(END_ALARM);
  if (state.seconds >= totalSeconds(state)) {
    console.log("Cure Brainrot: time is over, closing short-video tabs");
    await closeAllBlocked();
  }
}

async function openQuiz(auto) {
  await loadLimit();
  const state = await loadState();
  if (auto && state.quizDate === todayKey()) return;
  if (state.retryAfter && Date.now() < state.retryAfter) {
    console.log("Cure Brainrot: quiz needs " + Math.ceil((state.retryAfter - Date.now()) / 1000) + " more seconds");
    return;
  }
  if (state.quizDate === todayKey() && !state.retryAfter) return;
  state.quizDate = todayKey();
  state.retryAfter = 0;
  state.quizzes = (state.quizzes || 0) + 1;
  await saveState(state);
  await chrome.tabs.create({ url: chrome.runtime.getURL("quiz/quiz.html") });
}

async function sync() {
  await loadLimit();
  const state = await loadState();
  if (isLocked(state)) {
    if (state.countingSince) {
      state.countingSince = 0;
      state.seconds = totalSeconds(state);
      await saveState(state);
    }
    await chrome.alarms.clear(END_ALARM);
    await closeAllBlocked();
    await openQuiz(true);
    return;
  }
  const tab = await blockedTabInFront();
  if (tab) await startCounting();
  else await stopCounting();
}

chrome.tabs.onActivated.addListener(() => {
  sync().catch((error) => console.warn("Cure Brainrot: activation sync failed", error.message));
});

chrome.tabs.onRemoved.addListener(() => {
  sync().catch((error) => console.warn("Cure Brainrot: close sync failed", error.message));
});

chrome.windows.onFocusChanged.addListener(() => {
  sync().catch((error) => console.warn("Cure Brainrot: focus sync failed", error.message));
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const url = changeInfo.url || tab.url;
  if (url && blockedName(url)) {
    loadState().then(async (state) => {
      if (isLocked(state) && (await closeTab(tabId))) await countClose(1);
    }).catch((error) => console.warn("Cure Brainrot: update check failed", error.message));
  }
  sync().catch((error) => console.warn("Cure Brainrot: update sync failed", error.message));
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "brainrotPopup") return;
  popupOpen += 1;
  sync().catch((error) => console.warn("Cure Brainrot: popup open sync failed", error.message));
  port.onDisconnect.addListener(() => {
    popupOpen = Math.max(0, popupOpen - 1);
    sync().catch((error) => console.warn("Cure Brainrot: popup close sync failed", error.message));
  });
});

async function applyQuizResult(result) {
  if (!result || typeof result.passed !== "boolean" || !result.at) return;
  const state = await loadState();
  const counted = Array.isArray(state.counted) ? state.counted : [];
  if (counted.indexOf(result.at) === -1) {
    counted.push(result.at);
    state.counted = counted.slice(-20);
    state.right = (state.right || 0) + (Number.isFinite(result.score) ? result.score : 0);
    state.total = (state.total || 0) + (Number.isFinite(result.total) ? result.total : 0);
    state.source = result.source === "ai" ? "ai" : "builtin";
    if (result.passed) state.passed = (state.passed || 0) + 1;
    await saveState(state);
  }
  if (!result.passed) {
    if (state.failedFor === result.at) return;
    state.failedFor = result.at;
    state.retryAfter = Date.now() + RETRY_MINUTES * 60 * 1000;
    state.quizDate = todayKey();
    await saveState(state);
    console.log("Cure Brainrot: quiz not passed, retry in " + RETRY_MINUTES + " minutes");
    await sync();
    return;
  }
  if (state.bonusFor === result.at) return;
  state.bonusSeconds = (state.bonusSeconds || 0) + BONUS_MINUTES * 60;
  state.bonusFor = result.at;
  state.quizDate = "";
  await saveState(state);
  console.log("Cure Brainrot: quiz passed, " + BONUS_MINUTES + " extra minutes unlocked");
  await sync();
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.lastQuiz) {
    applyQuizResult(changes.lastQuiz.newValue).catch((error) => console.warn("Cure Brainrot: quiz result failed", error.message));
  }
  if (!changes[LIMIT_KEY]) return;
  scheduleEnd().then(sync).catch((error) => console.warn("Cure Brainrot: limit change failed", error.message));
});

chrome.alarms.create("cureBrainrotTick", { periodInMinutes: 0.5 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== "cureBrainrotTick" && alarm.name !== END_ALARM) return;
  sync().catch((error) => console.warn("Cure Brainrot: tick failed", error.message));
});

chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === "openQuiz") {
    openQuiz().catch((error) => console.warn("Cure Brainrot: could not open quiz", error.message));
    return;
  }
  if (message && message.type === "timeUp") {
    console.log("Cure Brainrot: timer page says time is up, closing short-video tabs");
    sync().catch((error) => console.warn("Cure Brainrot: time-up sync failed", error.message));
  }
});

chrome.tabs.onCreated.addListener((tab) => {
  if (!tab.url) return;
  loadState().then(async (state) => {
    if (blockedName(tab.url) && isLocked(state) && (await closeTab(tab.id))) await countClose(1);
  }).catch((error) => console.warn("Cure Brainrot: new tab check failed", error.message));
  sync().catch((error) => console.warn("Cure Brainrot: new tab sync failed", error.message));
});

chrome.runtime.onStartup.addListener(() => {
  sync().catch((error) => console.warn("Cure Brainrot: startup sync failed", error.message));
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.remove(STATE_KEY).catch((error) => {
    console.warn("Cure Brainrot: reset on update failed", error.message);
  });
  console.log("Cure Brainrot: installed or updated, timer reset");
});
