if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.connect) {
  chrome.runtime.connect({ name: "brainrotPopup" });
}

function showNote(text) {
  document.getElementById("note").textContent = text;
}

let toldBackground = false;

function paint(state) {
  const leftSeconds = Math.max(0, Math.ceil(totalSeconds(state) - usedSeconds(state)));
  const totalMinutes = Math.round(totalSeconds(state) / 60);
  const minutes = Math.floor(leftSeconds / 60);
  const seconds = leftSeconds % 60;
  document.getElementById("big").textContent = `${minutes}:${String(seconds).padStart(2, "0")}`;
  const watched = Math.floor(usedSeconds(state) / 60);
  const closed = state.tabsClosed || 0;
  document.getElementById("today").textContent =
    `Today: ${watched} min watched · ${closed} tab${closed === 1 ? "" : "s"} closed · ` +
    `quizzes ${state.quizzes || 0} (passed ${state.passed || 0}) · right ${state.right || 0}/${state.total || 0}`;
  document.getElementById("label").textContent = leftSeconds <= 0
    ? "short videos are closed until tomorrow"
    : state.countingSince ? "counting" : `of your ${totalMinutes} minute${totalMinutes === 1 ? "" : "s"} today`;
  if (leftSeconds <= 0 && !toldBackground) {
    toldBackground = true;
    chrome.runtime.sendMessage({ type: "timeUp" }).catch(() => {});
  }
}

async function start() {
  await loadLimit();
  document.getElementById("limit").value = LIMIT_MINUTES;
  const first = await loadState();
  paint(first);
  setInterval(async () => {
    const state = await loadState();
    paint(state);
  }, 1000);
}

function sourceWord(source) {
  if (source === "ai") return "AI";
  if (source === "builtin") return "built-in";
  return "no quiz yet";
}

async function resultLine() {
  const state = await loadState();
  const stored = await chrome.storage.local.get("userName");
  const name = (stored.userName || "").trim() || "user";
  const day = new Date().toLocaleDateString("en-GB", { day: "numeric", month: "short" });
  const watched = Math.floor(usedSeconds(state) / 60);
  const closed = state.tabsClosed || 0;
  return `${name} · ${day} · watched ${watched} min · tabs closed ${closed} · ` +
    `quizzes ${state.quizzes || 0} (passed ${state.passed || 0}) · ` +
    `right ${state.right || 0}/${state.total || 0} · ${sourceWord(state.source)}`;
}

async function copyText(line) {
  try {
    await navigator.clipboard.writeText(line);
    return true;
  } catch (error) {
    const box = document.createElement("textarea");
    box.value = line;
    document.body.appendChild(box);
    box.select();
    const ok = document.execCommand("copy");
    box.remove();
    return ok;
  }
}

document.getElementById("btn-copy").addEventListener("click", async () => {
  try {
    const line = await resultLine();
    const ok = await copyText(line);
    showNote(ok ? `Copied: ${line}` : `Could not copy. Here it is: ${line}`);
  } catch (error) {
    showNote(`Error: ${error.message}`);
  }
});

async function showNameState() {
  const stored = await chrome.storage.local.get("userName");
  document.getElementById("user-name").value = (stored.userName || "").trim();
}

document.getElementById("btn-save-name").addEventListener("click", async () => {
  const value = document.getElementById("user-name").value.trim();
  if (!value) {
    showNote("Type your name first");
    return;
  }
  await chrome.storage.local.set({ userName: value });
  showNote(`Name saved: ${value}`);
});

showNameState().catch((error) => {
  showNote(`Error: ${error.message}`);
});

async function hasKey() {
  const stored = await chrome.storage.local.get("llmKey");
  return !!(stored.llmKey && String(stored.llmKey).trim());
}

async function showKeyState() {
  document.getElementById("key").value = "";
  showNote((await hasKey()) ? "AI key saved on this computer" : "No AI key yet");
}

document.getElementById("btn-save-key").addEventListener("click", async () => {
  const value = document.getElementById("key").value.trim();
  if (!value) {
    showNote("Type your AI key first");
    return;
  }
  await chrome.storage.local.set({ llmKey: value });
  await showKeyState();
});

document.getElementById("btn-remove-key").addEventListener("click", async () => {
  await chrome.storage.local.set({ llmKey: "" });
  await showKeyState();
});

showKeyState().catch((error) => {
  showNote(`Error: ${error.message}`);
});

document.getElementById("btn-save-limit").addEventListener("click", async () => {
  const value = Number(document.getElementById("limit").value);
  if (!Number.isFinite(value) || value < 1 || value > 600) {
    showNote("Limit must be 1 to 600 minutes");
    return;
  }
  await chrome.storage.local.set({ limitMinutes: Math.round(value) });
  await loadLimit();
  document.getElementById("limit").value = LIMIT_MINUTES;
  showNote(`Limit saved: ${LIMIT_MINUTES} minutes`);
  paint(await loadState());
});

document.getElementById("btn-quiz").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "openQuiz" }).catch((error) => {
    showNote(`Error: ${error.message}`);
  });
});

start().catch((error) => {
  showNote(`Error: ${error.message}`);
});
