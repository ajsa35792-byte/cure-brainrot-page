const STATE_KEY = "cureBrainrot";
const LIMIT_KEY = "limitMinutes";
const DEFAULT_LIMIT = 20;
const BONUS_MINUTES = 20;
const RETRY_MINUTES = 5;
let LIMIT_MINUTES = DEFAULT_LIMIT;

async function loadLimit() {
  const stored = await chrome.storage.local.get(LIMIT_KEY);
  const value = Number(stored[LIMIT_KEY]);
  LIMIT_MINUTES = Number.isFinite(value) && value >= 1 && value <= 600 ? Math.round(value) : DEFAULT_LIMIT;
  return LIMIT_MINUTES;
}

function todayKey(date = new Date()) {
  const pad = (value) => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function emptyState() {
  return {
    date: todayKey(), seconds: 0, countingSince: 0, bonusSeconds: 0, retryAfter: 0,
    tabsClosed: 0, quizzes: 0, passed: 0, right: 0, total: 0, source: "", counted: []
  };
}

function totalSeconds(state) {
  return LIMIT_MINUTES * 60 + (state.bonusSeconds || 0);
}

async function loadState() {
  const stored = await chrome.storage.local.get(STATE_KEY);
  const state = { ...emptyState(), ...(stored[STATE_KEY] || {}) };
  if (state.date !== todayKey()) {
    state.date = todayKey();
    state.seconds = 0;
    state.countingSince = 0;
    state.bonusSeconds = 0;
    state.retryAfter = 0;
    state.tabsClosed = 0;
    state.quizzes = 0;
    state.passed = 0;
    state.right = 0;
    state.total = 0;
    state.source = "";
    state.counted = [];
    await saveState(state);
  }
  return state;
}

async function saveState(state) {
  await chrome.storage.local.set({ [STATE_KEY]: state });
}

function usedSeconds(state, now = Date.now()) {
  const live = state.countingSince ? Math.max(0, (now - state.countingSince) / 1000) : 0;
  return Math.min(totalSeconds(state), state.seconds + live);
}

function isLocked(state) {
  return usedSeconds(state) >= totalSeconds(state);
}

function minutesLeft(state) {
  return Math.max(0, Math.ceil((totalSeconds(state) - usedSeconds(state)) / 60));
}
