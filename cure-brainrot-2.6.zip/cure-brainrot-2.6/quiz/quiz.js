(function () {
  const I18N = {
    en: {
      popupKicker: "Social media",
      popupQuestion: "Do you want to open this tab?",
      popupNote: "One short quiz before the feed.",
      yes: "Yes",
      no: "No",
      closedTitle: "Tab closed. See you tomorrow!",
      closedText: "Nothing to scroll here.",
      reopen: "Open again",
      chooseLang: "Choose your screen language",
      chooseGrade: "What is your grade?",
      settings: "Settings",
      subjects: "Subjects",
      chooseSubjects: "What do you want to study?",
      moreThanOne: "You can pick more than one.",
      continueBtn: "Continue",
      addSubject: "Add subject",
      subjectName: "New subject",
      add: "Add",
      makingTopics: "The AI is making topics…",
      topicsFailed: "Could not make topics:",
      subMath: "Math",
      subSocial: "Social Studies",
      subScience: "Science",
      language: "Language",
      gradeWord: "Grade",
      close: "Close",
      loadingText: "The AI is writing your questions…",
      loadingFailed: "The AI could not make the questions.",
      retry: "Try again",
      useFixed: "Use the fixed questions",
      keyLabel: "AI key (optional)",
      offlineNote: "The AI is not available here, so these are the built-in questions.",
      aiOffline: "The AI is not available here. Try again later, or pick Math to use the built-in questions.",
      focusTitle: "Today's focus",
      focusHint: "The last quiz missed these topics. Today starts with them.",
      ok: "Ok",
      gradeLabel: "Grade {n}",
      math: "Math",
      counter: "Question {n} of 10",
      next: "Next",
      right: "Correct!",
      wrong: "Not quite. The right answer is: {a}",
      scoreLabel: "You got",
      scoreText: "{s} of 10 correct",
      passed: "Passed: 20 extra minutes unlocked.",
      failed: "Not passed: 8 of 10 are needed.",
      weak: "Weak topics: {list}",
      again: "Play again",
      retryWait: "Try again in {s}",
      note: ""
    },
    ru: {
      popupKicker: "Соцсети",
      popupQuestion: "Открыть эту вкладку?",
      popupNote: "Один короткий тест перед лентой.",
      yes: "Да",
      no: "Нет",
      closedTitle: "Вкладка закрыта. До завтра!",
      closedText: "Листать здесь нечего.",
      reopen: "Открыть снова",
      chooseLang: "Выбери язык экрана",
      chooseGrade: "В каком ты классе?",
      settings: "Настройки",
      subjects: "Предметы",
      chooseSubjects: "Что ты хочешь изучать?",
      moreThanOne: "Можно выбрать несколько.",
      continueBtn: "Продолжить",
      addSubject: "Добавить предмет",
      subjectName: "Новый предмет",
      add: "Добавить",
      makingTopics: "ИИ составляет темы…",
      topicsFailed: "Не удалось составить темы:",
      subMath: "Математика",
      subSocial: "Обществознание",
      subScience: "Естествознание",
      language: "Язык",
      gradeWord: "Класс",
      close: "Закрыть",
      loadingText: "ИИ пишет твои вопросы…",
      loadingFailed: "ИИ не смог составить вопросы.",
      retry: "Ещё раз",
      useFixed: "Взять готовые вопросы",
      keyLabel: "Ключ ИИ (необязательно)",
      offlineNote: "ИИ здесь недоступен, поэтому это готовые вопросы.",
      aiOffline: "ИИ здесь недоступен. Попробуйте позже или выберите математику с готовыми вопросами.",
      focusTitle: "Сегодня в фокусе",
      focusHint: "В прошлый раз эти темы не получились. Сегодня начнём с них.",
      ok: "Ок",
      gradeLabel: "{n} класс",
      math: "Математика",
      counter: "Вопрос {n} из 10",
      next: "Дальше",
      right: "Верно!",
      wrong: "Не совсем. Правильный ответ: {a}",
      scoreLabel: "Твой результат",
      scoreText: "{s} из 10 верно",
      passed: "Сдано: открыто 20 дополнительных минут.",
      failed: "Не сдано: нужно 8 из 10.",
      weak: "Слабые темы: {list}",
      again: "Играть снова",
      retryWait: "Попробуйте снова через {s}",
      note: ""
    },
    kk: {
      popupKicker: "Әлеуметтік желі",
      popupQuestion: "Осы бетті ашасың ба?",
      popupNote: "Лента алдында бір қысқа тест.",
      yes: "Иә",
      no: "Жоқ",
      closedTitle: "Бет жабылды. Ертең кездескенше!",
      closedText: "Мұнда айналдыратын ештеңе жоқ.",
      reopen: "Қайта ашу",
      chooseLang: "Экран тілін таңда",
      chooseGrade: "Қай сыныпта оқисың?",
      settings: "Баптаулар",
      subjects: "Пәндер",
      chooseSubjects: "Нені оқығың келеді?",
      moreThanOne: "Бірнешеуін таңдауға болады.",
      continueBtn: "Жалғастыру",
      addSubject: "Пән қосу",
      subjectName: "Жаңа пән",
      add: "Қосу",
      makingTopics: "ЖИ тақырыптарды құрастырып жатыр…",
      topicsFailed: "Тақырыптарды құру мүмкін болмады:",
      subMath: "Математика",
      subSocial: "Қоғамтану",
      subScience: "Жаратылыстану",
      language: "Тіл",
      gradeWord: "Сынып",
      close: "Жабу",
      loadingText: "ЖИ сенің сұрақтарыңды жазып жатыр…",
      loadingFailed: "ЖИ сұрақтарды құра алмады.",
      retry: "Қайталау",
      useFixed: "Дайын сұрақтарды алу",
      keyLabel: "ИИ кілті (міндетті емес)",
      offlineNote: "Мұнда ИИ жоқ, сондықтан бұл дайын сұрақтар.",
      aiOffline: "Мұнда ИИ жоқ. Кейінірек көріңіз немесе математиканы таңдап, дайын сұрақтарды алыңыз.",
      focusTitle: "Бүгінгі назар",
      focusHint: "Өткен жолы осы тақырыптар қиын болды. Бүгін олардан бастаймыз.",
      ok: "Ок",
      gradeLabel: "{n}-сынып",
      math: "Математика",
      counter: "Сұрақ {n} / 10",
      next: "Келесі",
      right: "Дұрыс!",
      wrong: "Дұрыс емес. Дұрыс жауап: {a}",
      scoreLabel: "Сенің нәтижең",
      scoreText: "10 сұрақтың {s}-і дұрыс",
      passed: "Тапсырдың: 20 қосымша минут ашылды.",
      failed: "Тапсырмадың: 10 сұрақтан 8 керек.",
      weak: "Әлсіз тақырыптар: {list}",
      again: "Қайта ойнау",
      retryWait: "Қайта көріңіз: {s}",
      note: ""
    }
  };

  const BANK = {
    5: [
      { topic: { en: "Addition", ru: "Сложение", kk: "Қосу" }, q: { en: "What is 345 + 278?", ru: "Сколько будет 345 + 278?", kk: "345 + 278 нешеге тең?" }, options: ["523", "613", "623", "723"], answer: 2 },
      { topic: { en: "Multiplication", ru: "Умножение", kk: "Көбейту" }, q: { en: "What is 7 × 8?", ru: "Сколько будет 7 × 8?", kk: "7 × 8 нешеге тең?" }, options: ["48", "54", "56", "64"], answer: 2 },
      { topic: { en: "Fractions", ru: "Дроби", kk: "Бөлшектер" }, q: { en: "What is 1/2 of 48?", ru: "Сколько составляет 1/2 от 48?", kk: "48-дің 1/2 бөлігі қанша?" }, options: ["12", "24", "26", "96"], answer: 1 },
      { topic: { en: "Subtraction", ru: "Вычитание", kk: "Алу" }, q: { en: "What is 900 − 465?", ru: "Сколько будет 900 − 465?", kk: "900 − 465 нешеге тең?" }, options: ["425", "435", "445", "535"], answer: 1 },
      { topic: { en: "Decimals", ru: "Десятичные дроби", kk: "Ондық бөлшектер" }, q: { en: "Which number is larger?", ru: "Какое число больше?", kk: "Қай сан үлкен?" }, options: { en: ["3.45", "3.5", "They are equal", "Cannot tell"], ru: ["3.45", "3.5", "Они равны", "Нельзя определить"], kk: ["3.45", "3.5", "Олар тең", "Анықтау мүмкін емес"] }, answer: 1 },
      { topic: { en: "Perimeter", ru: "Периметр", kk: "Периметр" }, q: { en: "A rectangle is 6 cm by 4 cm. What is its perimeter?", ru: "Прямоугольник 6 см на 4 см. Чему равен периметр?", kk: "Тіктөртбұрыштың қабырғалары 6 см және 4 см. Периметрі қанша?" }, options: { en: ["10 cm", "20 cm", "24 cm", "28 cm"], ru: ["10 см", "20 см", "24 см", "28 см"], kk: ["10 см", "20 см", "24 см", "28 см"] }, answer: 1 },
      { topic: { en: "Percentages", ru: "Проценты", kk: "Пайыздар" }, q: { en: "What is 25% of 80?", ru: "Сколько составляет 25% от 80?", kk: "80-нің 25%-ы қанша?" }, options: ["16", "20", "25", "40"], answer: 1 },
      { topic: { en: "Rounding", ru: "Округление", kk: "Дөңгелектеу" }, q: { en: "Round 3,472 to the nearest hundred.", ru: "Округли 3 472 до сотен.", kk: "3 472-ні жүздікке дейін дөңгелекте." }, options: ["3,400", "3,470", "3,500", "4,000"], answer: 2 },
      { topic: { en: "Division", ru: "Деление", kk: "Бөлу" }, q: { en: "What is 144 ÷ 12?", ru: "Сколько будет 144 ÷ 12?", kk: "144 ÷ 12 нешеге тең?" }, options: ["10", "11", "12", "14"], answer: 2 },
      { topic: { en: "Decimals", ru: "Десятичные дроби", kk: "Ондық бөлшектер" }, q: { en: "What is 3/10 as a decimal?", ru: "Запиши 3/10 десятичной дробью.", kk: "3/10-ды ондық бөлшек түрінде жаз." }, options: ["0.03", "0.3", "3.0", "30"], answer: 1 }
    ],
    6: [
      { topic: { en: "Fractions", ru: "Дроби", kk: "Бөлшектер" }, q: { en: "What is 3/4 + 1/4?", ru: "Сколько будет 3/4 + 1/4?", kk: "3/4 + 1/4 нешеге тең?" }, options: ["1", "4/8", "1/2", "2"], answer: 0 },
      { topic: { en: "Percentages", ru: "Проценты", kk: "Пайыздар" }, q: { en: "What is 15% of 200?", ru: "Сколько составляет 15% от 200?", kk: "200-дің 15%-ы қанша?" }, options: ["15", "20", "30", "35"], answer: 2 },
      { topic: { en: "Equations", ru: "Уравнения", kk: "Теңдеулер" }, q: { en: "Solve: 2x + 5 = 17. What is x?", ru: "Реши уравнение: 2x + 5 = 17. Чему равен x?", kk: "Теңдеуді шеш: 2x + 5 = 17. x нешеге тең?" }, options: ["4", "5", "6", "11"], answer: 2 },
      { topic: { en: "Area", ru: "Площадь", kk: "Аудан" }, q: { en: "A rectangle is 8 cm by 5 cm. What is its area?", ru: "Прямоугольник 8 см на 5 см. Чему равна площадь?", kk: "Тіктөртбұрыш 8 см және 5 см. Ауданы қанша?" }, options: { en: ["13 cm²", "26 cm²", "40 cm²", "80 cm²"], ru: ["13 см²", "26 см²", "40 см²", "80 см²"], kk: ["13 см²", "26 см²", "40 см²", "80 см²"] }, answer: 2 },
      { topic: { en: "Decimals", ru: "Десятичные дроби", kk: "Ондық бөлшектер" }, q: { en: "Which number is larger?", ru: "Какое число больше?", kk: "Қай сан үлкен?" }, options: { en: ["0.65", "0.7", "They are equal", "Cannot tell"], ru: ["0.65", "0.7", "Они равны", "Нельзя определить"], kk: ["0.65", "0.7", "Олар тең", "Анықтау мүмкін емес"] }, answer: 1 },
      { topic: { en: "Multiplication", ru: "Умножение", kk: "Көбейту" }, q: { en: "What is 12 × 12?", ru: "Сколько будет 12 × 12?", kk: "12 × 12 нешеге тең?" }, options: ["124", "132", "144", "154"], answer: 2 },
      { topic: { en: "Perimeter", ru: "Периметр", kk: "Периметр" }, q: { en: "A square has a side of 9 cm. What is its perimeter?", ru: "Сторона квадрата 9 см. Чему равен периметр?", kk: "Шаршының қабырғасы 9 см. Периметрі қанша?" }, options: { en: ["18 cm", "27 cm", "36 cm", "81 cm"], ru: ["18 см", "27 см", "36 см", "81 см"], kk: ["18 см", "27 см", "36 см", "81 см"] }, answer: 2 },
      { topic: { en: "Average", ru: "Среднее", kk: "Орташа мән" }, q: { en: "What is the average of 4, 8, 10 and 14?", ru: "Чему равно среднее чисел 4, 8, 10 и 14?", kk: "4, 8, 10 және 14 сандарының орташа мәні қанша?" }, options: ["8", "9", "10", "12"], answer: 1 },
      { topic: { en: "Percentages", ru: "Проценты", kk: "Пайыздар" }, q: { en: "What is 1/2 as a percent?", ru: "Запиши 1/2 в процентах.", kk: "1/2-ні пайызбен жаз." }, options: ["12%", "25%", "50%", "100%"], answer: 2 },
      { topic: { en: "Expressions", ru: "Выражения", kk: "Өрнектер" }, q: { en: "If a = 3, what is 4a − 5?", ru: "Если a = 3, чему равно 4a − 5?", kk: "Егер a = 3 болса, 4a − 5 нешеге тең?" }, options: ["7", "9", "12", "17"], answer: 0 }
    ],
    7: [
      { topic: { en: "Equations", ru: "Уравнения", kk: "Теңдеулер" }, q: { en: "Solve: 3x − 7 = 14. What is x?", ru: "Реши: 3x − 7 = 14. Чему равен x?", kk: "Шеш: 3x − 7 = 14. x нешеге тең?" }, options: ["5", "6", "7", "9"], answer: 2 },
      { topic: { en: "Negative numbers", ru: "Отрицательные числа", kk: "Теріс сандар" }, q: { en: "What is (−5) + 8?", ru: "Сколько будет (−5) + 8?", kk: "(−5) + 8 нешеге тең?" }, options: ["−13", "−3", "3", "13"], answer: 2 },
      { topic: { en: "Powers", ru: "Степени", kk: "Дәрежелер" }, q: { en: "What is 2³?", ru: "Сколько будет 2³?", kk: "2³ нешеге тең?" }, options: ["6", "8", "9", "12"], answer: 1 },
      { topic: { en: "Percentages", ru: "Проценты", kk: "Пайыздар" }, q: { en: "What is 30% of 150?", ru: "Сколько составляет 30% от 150?", kk: "150-нің 30%-ы қанша?" }, options: ["30", "45", "50", "60"], answer: 1 },
      { topic: { en: "Equations", ru: "Уравнения", kk: "Теңдеулер" }, q: { en: "Solve: x / 4 = 9. What is x?", ru: "Реши: x / 4 = 9. Чему равен x?", kk: "Шеш: x / 4 = 9. x нешеге тең?" }, options: ["13", "27", "36", "45"], answer: 2 },
      { topic: { en: "Order of operations", ru: "Порядок действий", kk: "Амалдар реті" }, q: { en: "What is 5 + 2 × 3?", ru: "Сколько будет 5 + 2 × 3?", kk: "5 + 2 × 3 нешеге тең?" }, options: ["11", "16", "21", "30"], answer: 0 },
      { topic: { en: "Ratio", ru: "Отношения", kk: "Қатынас" }, q: { en: "A ratio is 2 : 3 and the total is 20. What is the smaller part?", ru: "Отношение 2 : 3, сумма 20. Чему равна меньшая часть?", kk: "Қатынас 2 : 3, қосындысы 20. Кіші бөлігі қанша?" }, options: ["6", "8", "10", "12"], answer: 1 },
      { topic: { en: "Area", ru: "Площадь", kk: "Аудан" }, q: { en: "A triangle has base 10 cm and height 6 cm. What is its area?", ru: "Основание треугольника 10 см, высота 6 см. Чему равна площадь?", kk: "Үшбұрыштың табаны 10 см, биіктігі 6 см. Ауданы қанша?" }, options: { en: ["16 cm²", "30 cm²", "60 cm²", "120 cm²"], ru: ["16 см²", "30 см²", "60 см²", "120 см²"], kk: ["16 см²", "30 см²", "60 см²", "120 см²"] }, answer: 1 },
      { topic: { en: "Negative numbers", ru: "Отрицательные числа", kk: "Теріс сандар" }, q: { en: "What is (−2) × (−3)?", ru: "Сколько будет (−2) × (−3)?", kk: "(−2) × (−3) нешеге тең?" }, options: ["−6", "−5", "5", "6"], answer: 3 },
      { topic: { en: "Prime numbers", ru: "Простые числа", kk: "Жай сандар" }, q: { en: "Which of these is a prime number?", ru: "Какое из этих чисел простое?", kk: "Осы сандардың қайсысы жай сан?" }, options: ["21", "27", "29", "33"], answer: 2 }
    ]
  };

  const SUBJECTS = ["math", "social", "science"];
  const SUBJECT_KEY = { math: "subMath", social: "subSocial", science: "subScience" };

  const TOPIC_LISTS = {
    science: {
      5: [
        { en: "Living and non-living things", ru: "Живая и неживая природа", kk: "Тірі және өлі табиғат" },
        { en: "Plants", ru: "Растения", kk: "Өсімдіктер" },
        { en: "Animals", ru: "Животные", kk: "Жануарлар" },
        { en: "Water cycle", ru: "Круговорот воды", kk: "Су айналымы" },
        { en: "States of matter", ru: "Состояния вещества", kk: "Зат күйлері" },
        { en: "Solar system", ru: "Солнечная система", kk: "Күн жүйесі" },
        { en: "Light", ru: "Свет", kk: "Жарық" },
        { en: "Sound", ru: "Звук", kk: "Дыбыс" }
      ],
      6: [
        { en: "Cells", ru: "Клетки", kk: "Жасушалар" },
        { en: "Food chains", ru: "Пищевые цепи", kk: "Қоректік тізбектер" },
        { en: "Photosynthesis", ru: "Фотосинтез", kk: "Фотосинтез" },
        { en: "Rocks and soil", ru: "Горные породы и почва", kk: "Тау жыныстары мен топырақ" },
        { en: "Electricity", ru: "Электричество", kk: "Электр" },
        { en: "Heat", ru: "Тепло", kk: "Жылу" },
        { en: "Mixtures", ru: "Смеси", kk: "Қоспалар" },
        { en: "Human body", ru: "Тело человека", kk: "Адам денесі" }
      ],
      7: [
        { en: "Atoms and elements", ru: "Атомы и элементы", kk: "Атомдар мен элементтер" },
        { en: "Chemical reactions", ru: "Химические реакции", kk: "Химиялық реакциялар" },
        { en: "Forces and motion", ru: "Силы и движение", kk: "Күштер және қозғалыс" },
        { en: "Energy", ru: "Энергия", kk: "Энергия" },
        { en: "Earth and space", ru: "Земля и космос", kk: "Жер және ғарыш" },
        { en: "Reproduction", ru: "Размножение", kk: "Көбею" },
        { en: "Light and optics", ru: "Свет и оптика", kk: "Жарық және оптика" },
        { en: "Ecology", ru: "Экология", kk: "Экология" }
      ]
    },
    social: {
      5: [
        { en: "My family and community", ru: "Семья и сообщество", kk: "Отбасы және қауым" },
        { en: "Kazakh traditions", ru: "Казахские традиции", kk: "Қазақ дәстүрлері" },
        { en: "Ancient people of Kazakhstan", ru: "Древние люди Казахстана", kk: "Қазақстанның ежелгі адамдары" },
        { en: "Maps and directions", ru: "Карты и направления", kk: "Карталар мен бағыттар" },
        { en: "Goods and services", ru: "Товары и услуги", kk: "Тауарлар мен қызметтер" },
        { en: "Rules and laws", ru: "Правила и законы", kk: "Ережелер мен заңдар" },
        { en: "Holidays", ru: "Праздники", kk: "Мерекелер" },
        { en: "Places of Kazakhstan", ru: "Места Казахстана", kk: "Қазақстанның орындары" }
      ],
      6: [
        { en: "Nomadic life", ru: "Кочевая жизнь", kk: "Көшпелі өмір" },
        { en: "The Silk Road", ru: "Великий Шёлковый путь", kk: "Ұлы Жібек жолы" },
        { en: "Kazakh Khanate", ru: "Казахское ханство", kk: "Қазақ хандығы" },
        { en: "Village and city life", ru: "Жизнь в селе и городе", kk: "Ауыл және қала өмірі" },
        { en: "Rights of a child", ru: "Права ребёнка", kk: "Бала құқықтары" },
        { en: "Money and trade", ru: "Деньги и торговля", kk: "Ақша және сауда" },
        { en: "World civilizations", ru: "Мировые цивилизации", kk: "Әлем өркениеттері" },
        { en: "Natural resources", ru: "Природные ресурсы", kk: "Табиғи ресурстар" }
      ],
      7: [
        { en: "Kazakhstan in the 20th century", ru: "Казахстан в XX веке", kk: "XX ғасырдағы Қазақстан" },
        { en: "Independence of Kazakhstan", ru: "Независимость Казахстана", kk: "Қазақстан тәуелсіздігі" },
        { en: "The Constitution", ru: "Конституция", kk: "Конституция" },
        { en: "Human rights", ru: "Права человека", kk: "Адам құқықтары" },
        { en: "Economy and work", ru: "Экономика и труд", kk: "Экономика және еңбек" },
        { en: "World religions", ru: "Мировые религии", kk: "Әлем діндері" },
        { en: "Democracy and elections", ru: "Демократия и выборы", kk: "Демократия және сайлау" },
        { en: "Global problems", ru: "Глобальные проблемы", kk: "Жаһандық мәселелер" }
      ]
    }
  };

  const TOPICS = {};
  Object.keys(BANK).forEach(function (grade) {
    BANK[grade].forEach(function (item) {
      TOPICS[item.topic.en] = item.topic;
    });
  });
  ["science", "social"].forEach(function (sub) {
    Object.keys(TOPIC_LISTS[sub]).forEach(function (grade) {
      TOPIC_LISTS[sub][grade].forEach(function (topic) {
        TOPICS[sub + ":" + topic.en] = { en: sub + ":" + topic.en, ru: topic.ru, kk: topic.kk };
      });
    });
  });

  function readSettings() {
    try {
      const raw = localStorage.getItem("settings");
      const saved = raw ? JSON.parse(raw) : null;
      if (saved && ["en", "ru", "kk"].indexOf(saved.lang) !== -1 && [5, 6, 7].indexOf(saved.grade) !== -1) {
        saved.custom = Array.isArray(saved.custom) ? saved.custom.filter(function (item) {
          return item && typeof item.id === "string" && typeof item.name === "string" && item.name.trim() && item.topics &&
            [5, 6, 7].every(function (grade) { return Array.isArray(item.topics[grade]) && item.topics[grade].length; });
        }) : [];
        const known = SUBJECTS.concat(saved.custom.map(function (item) { return item.id; }));
        saved.subjects = Array.isArray(saved.subjects)
          ? saved.subjects.filter(function (sub, i) { return known.indexOf(sub) !== -1 && saved.subjects.indexOf(sub) === i; })
          : [];
        if (!saved.subjects.length) saved.subjects = ["math"];
        if ("key" in saved) {
          delete saved.key;
          try {
            localStorage.setItem("settings", JSON.stringify(saved));
          } catch (error) {
            console.warn("Cure Brainrot: cannot clean the old key", error.message);
          }
        }
        return saved;
      }
      return null;
    } catch (error) {
      console.warn("Cure Brainrot: cannot read settings", error.message);
      return null;
    }
  }

  const savedSettings = readSettings();
  const state = {
    lang: savedSettings ? savedSettings.lang : "en",
    grade: savedSettings ? savedSettings.grade : 6,
    hasSettings: !!savedSettings,
    subjects: savedSettings ? savedSettings.subjects : ["math"],
    custom: savedSettings && Array.isArray(savedSettings.custom) ? savedSettings.custom : [],
    screen: "popup",
    index: 0, score: 0, weakTopics: [], focus: [], queue: [], locked: false, source: "builtin"
  };

  function saveSettings() {
    state.hasSettings = true;
    const data = { lang: state.lang, grade: state.grade, subjects: state.subjects.slice(), custom: state.custom };
    try {
      localStorage.setItem("settings", JSON.stringify(data));
    } catch (error) {
      console.warn("Cure Brainrot: cannot save settings", error.message);
    }
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ settings: data }).catch(function (error) {
        console.warn("Cure Brainrot: could not save settings", error.message);
      });
    }
  }

  const LLM = "https://kitan-a.com/frp/llm/v1";

  function storedKey() {
    if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) return Promise.resolve("");
    return chrome.storage.local.get("llmKey").then(function (stored) {
      return stored && typeof stored.llmKey === "string" ? stored.llmKey.trim() : "";
    }).catch(function (error) {
      console.warn("Cure Brainrot: cannot read the saved AI key", error.message);
      return "";
    });
  }

  function headers(key) {
    const head = { "Content-Type": "application/json" };
    if (key) head.Authorization = "Bearer " + key;
    return head;
  }

  const el = (id) => document.getElementById(id);
  const screens = ["popup", "closed", "setup", "quiz", "loading", "focus", "score"];
  const t = (key) => {
    const dict = I18N[state.lang] || I18N.en;
    return key in dict ? dict[key] : (I18N.en[key] ?? key);
  };
  const textFor = (obj) => obj[state.lang] || obj.en;
  const subName = (sub) => {
    if (SUBJECT_KEY[sub]) return t(SUBJECT_KEY[sub]);
    const custom = state.custom.find(function (item) { return item.id === sub; });
    return custom ? custom.name : sub;
  };
  const allSubjects = () => SUBJECTS.concat(state.custom.map(function (item) { return item.id; }));
  const topicsFor = (sub, grade) => {
    if (sub === "math") return null;
    const custom = state.custom.find(function (item) { return item.id === sub; });
    return custom ? custom.topics[grade] : TOPIC_LISTS[sub][grade];
  };
  const topicLabel = (key) => {
    const name = key.indexOf(":") !== -1 ? key.split(":").slice(1).join(":") : key;
    const topic = TOPICS[key];
    if (state.lang !== "en" && topic && topic[state.lang]) return topic[state.lang];
    return name;
  };
  const optsFor = (item) => Array.isArray(item.options) ? item.options : (item.options[state.lang] || item.options.en);

  function fill(text, value) {
    return String(text).replace("{n}", value).replace("{s}", value).replace("{a}", value).replace("{list}", value);
  }

  function show(which) {
    state.screen = which;
    screens.forEach((name) => {
      el("screen-" + name).classList.toggle("on", name === which);
    });
    window.scrollTo(0, 0);
  }

  function applyLanguage() {
    document.documentElement.lang = state.lang;
    el("popup-kicker").textContent = t("popupKicker");
    el("popup-question").textContent = t("popupQuestion");
    el("popup-note").textContent = t("popupNote");
    el("btn-yes").textContent = t("yes");
    el("btn-no").textContent = t("no");
    el("closed-title").textContent = t("closedTitle");
    el("closed-text").textContent = t("closedText");
    el("btn-reopen").textContent = t("reopen");
    el("btn-again").textContent = t("again");
    el("btn-next").textContent = t("next");
    el("quiz-note").textContent = t("note");
    el("score-note").textContent = t("note");
    el("quiz-subject").textContent = state.subjects.map(subName).join(" · ");
    el("loading-text").textContent = t("loadingText");
    refreshMenu();
    el("btn-retry").textContent = t("retry");
    el("btn-fixed").textContent = t("useFixed");
    el("focus-title").textContent = t("focusTitle");
    el("focus-hint").textContent = t("focusHint");
    el("btn-ok").textContent = t("ok");
  }

  function renderSetup(step) {
    const box = el("setup-options");
    box.innerHTML = "";
    el("setup-note").textContent = "";
    if (step === "lang") {
      el("setup-title").textContent = t("chooseLang");
      [["en", "English"], ["ru", "Русский"], ["kk", "Қазақша"]].forEach(function (pair) {
        const b = document.createElement("button");
        b.textContent = pair[1];
        b.addEventListener("click", function () {
          state.lang = pair[0];
          applyLanguage();
          renderSetup("grade");
        });
        box.appendChild(b);
      });
    } else if (step === "grade") {
      el("setup-title").textContent = t("chooseGrade");
      [5, 6, 7].forEach(function (grade) {
        const b = document.createElement("button");
        b.textContent = fill(t("gradeLabel"), grade);
        b.addEventListener("click", function () {
          state.grade = grade;
          renderSetup("subjects");
        });
        box.appendChild(b);
      });
    } else {
      el("setup-title").textContent = t("chooseSubjects");
      el("setup-note").textContent = t("moreThanOne");
      allSubjects().forEach(function (sub) {
        const b = document.createElement("button");
        b.className = "chip";
        b.classList.toggle("on", state.subjects.indexOf(sub) !== -1);
        b.textContent = subName(sub);
        b.addEventListener("click", function () {
          toggleSubject(sub);
          saveSettings();
          renderSetup("subjects");
        });
        box.appendChild(b);
      });
      const go = document.createElement("button");
      go.className = "primary";
      go.style.flexBasis = "100%";
      go.textContent = t("continueBtn");
      go.addEventListener("click", function () {
        saveSettings();
        startQuiz(state.grade);
      });
      box.appendChild(go);
    }
  }

  function readLastQuiz() {
    try {
      const raw = localStorage.getItem("lastQuiz");
      return raw ? JSON.parse(raw) : null;
    } catch (error) {
      console.warn("Cure Brainrot: cannot read the last quiz", error.message);
      return null;
    }
  }

  function registerCustomTopics() {
    state.custom.forEach(function (item) {
      [5, 6, 7].forEach(function (grade) {
        item.topics[grade].forEach(function (topic) {
          TOPICS[item.id + ":" + topic.en] = { en: item.id + ":" + topic.en, ru: topic.ru, kk: topic.kk };
        });
      });
    });
  }

  function toggleSubject(sub) {
    const at = state.subjects.indexOf(sub);
    if (at === -1) {
      state.subjects.push(sub);
      return;
    }
    if (state.subjects.length <= 1) return;
    state.subjects.splice(at, 1);
    if (SUBJECT_KEY[sub]) return;
    state.custom = state.custom.filter(function (item) { return item.id !== sub; });
    Object.keys(TOPICS).forEach(function (key) {
      if (key.indexOf(sub + ":") === 0) delete TOPICS[key];
    });
  }

  function startQuiz(grade) {
    state.grade = grade;
    const last = readLastQuiz();
    const missed = last && Array.isArray(last.weakTopics) ? last.weakTopics : [];
    const inGrade = [];
    if (state.subjects.indexOf("math") !== -1) {
      BANK[grade].forEach(function (item) {
        if (inGrade.indexOf(item.topic.en) === -1) inGrade.push(item.topic.en);
      });
    }
    allSubjects().forEach(function (sub) {
      if (sub === "math" || state.subjects.indexOf(sub) === -1) return;
      topicsFor(sub, grade).forEach(function (topic) {
        inGrade.push(sub + ":" + topic.en);
      });
    });
    state.focus = missed.filter(function (name, i) {
      return inGrade.indexOf(name) !== -1 && missed.indexOf(name) === i;
    });
    if (state.focus.length) {
      const box = el("focus-list");
      box.innerHTML = "";
      state.focus.forEach(function (name) {
        const row = document.createElement("button");
        row.disabled = true;
        row.textContent = topicLabel(name);
        box.appendChild(row);
      });
      show("focus");
      return;
    }
    beginQuiz();
  }

  function orderFocus(list) {
    return list.slice().sort(function (a, b) {
      const fa = state.focus.indexOf(a.topic.en) !== -1 ? 0 : 1;
      const fb = state.focus.indexOf(b.topic.en) !== -1 ? 0 : 1;
      return fa - fb;
    });
  }

  function shuffleOptions(item) {
    const right = item.options[item.answer];
    const mixed = item.options.slice();
    for (let i = mixed.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const tmp = mixed[i];
      mixed[i] = mixed[j];
      mixed[j] = tmp;
    }
    item.options = mixed;
    item.answer = mixed.indexOf(right);
    return item;
  }

  async function askSubject(sub, count) {
    const API = LLM;
    const langName = { en: "English", ru: "Russian", kk: "Kazakh" }[state.lang];
    const subjectEn = sub === "math" ? "math" : subName(sub).toLowerCase();
    let topicRule;
    if (sub === "math") {
      const topics = [];
      BANK[state.grade].forEach(function (item) {
        if (topics.indexOf(item.topic.en) === -1) topics.push(item.topic.en);
      });
      topicRule = "topic must be exactly one of these English keys: " + topics.join(", ") + ".";
    } else {
      const keys = topicsFor(sub, state.grade).map(function (topic) { return topic.en; });
      topicRule = "topic must be exactly one of these English keys: " + keys.join(", ") + ".";
    }
    const focusHere = state.focus.filter(function (key) {
      return sub === "math" ? key.indexOf(":") === -1 : key.indexOf(sub + ":") === 0;
    }).map(function (key) {
      return key.indexOf(":") === -1 ? key : key.split(":").slice(1).join(":");
    });
    const focusRule = focusHere.length
      ? " Start with questions on these topics, one question each if you can: " + focusHere.join(", ") + "."
      : "";
    const prompt = "Write " + count + " multiple-choice " + subjectEn + " questions for grade " + state.grade + " in " + langName + ". " +
      topicRule + focusRule + " Each question: 4 options, exactly one right, answer = index 0-3, no repeated questions. " +
      'JSON only, no text outside: [{"topic":"Fractions","q":"...","options":["","","",""],"answer":0}]';
    const r = await fetch(API + "/chat/completions", {
      method: "POST",
      headers: headers(await storedKey()),
      body: JSON.stringify({
        model: "dsv41",
        temperature: 0.7,
        messages: [{ role: "user", content: prompt }]
      })
    });
    if (!r.ok) {
      const body = (await r.text()).slice(0, 200);
      throw new Error("AI server " + r.status + ": " + body);
    }
    const data = await r.json();
    const raw = data.choices[0].message.content.trim().replace(/^```(?:json)?/, "").replace(/```$/, "");
    const start = raw.indexOf("[");
    const end = raw.lastIndexOf("]");
    if (start === -1 || end === -1) throw new Error("AI answer is not JSON: " + raw.slice(0, 200));
    const list = JSON.parse(raw.slice(start, end + 1));
    if (!Array.isArray(list)) throw new Error("AI answer is not a list of questions");
    const keys = sub === "math"
      ? BANK[state.grade].map(function (item) { return item.topic.en; }).filter(function (name, i, all) { return all.indexOf(name) === i; })
      : topicsFor(sub, state.grade).map(function (topic) { return topic.en; });
    const normalize = function (name) {
      const clean = String(name || "").trim();
      const key = sub === "math" ? clean : sub + ":" + clean;
      if (TOPICS[key]) return TOPICS[key];
      const lower = key.toLowerCase();
      const found = Object.keys(TOPICS).filter(function (k) { return k.toLowerCase() === lower; })[0];
      return found ? TOPICS[found] : null;
    };
    const first = keys.length
      ? (sub === "math" ? TOPICS[keys[0]] : TOPICS[sub + ":" + keys[0]])
      : { en: subName(sub), ru: subName(sub), kk: subName(sub) };
    const good = list.filter(function (item) {
      return item && typeof item.q === "string" && item.q.trim() &&
        Array.isArray(item.options) && item.options.length === 4 &&
        item.options.every(function (o) { return typeof o === "string" && o.trim(); }) &&
        Number.isInteger(item.answer) && item.answer >= 0 && item.answer <= 3;
    }).slice(0, count);
    if (!good.length) throw new Error(subName(sub) + ": no questions from the AI");
    return good.map(function (item) {
      return shuffleOptions({
        topic: normalize(item.topic) || first,
        q: { en: item.q },
        options: item.options.slice(),
        answer: item.answer
      });
    });
  }

  async function subjectQuestions(sub, count) {
    let got = await askSubject(sub, count);
    if (got.length < count && count - got.length >= 2) {
      const more = await askSubject(sub, count - got.length);
      got = got.concat(more);
    }
    return got.slice(0, count);
  }

  async function aiQuestions() {
    const subs = state.subjects.slice();
    const base = Math.floor(10 / subs.length);
    const extra = 10 - base * subs.length;
    const parts = await Promise.all(subs.map(function (sub, i) {
      return subjectQuestions(sub, base + (i < extra ? 1 : 0));
    }));
    return parts.reduce(function (all, part) { return all.concat(part); }, []);
  }


  async function makeQuiz() {
    el("quiz-subject").textContent = state.subjects.map(subName).join(" · ");
    el("loading-error").textContent = "";
    el("btn-retry").hidden = true;
    el("btn-fixed").hidden = true;
    el("loading-text").textContent = t("loadingText");
    refreshMenu();
    show("loading");
    let list;
    try {
      list = orderFocus(await aiQuestions());
    } catch (error) {
      console.warn("Cure Brainrot: AI questions failed", error.message);
      if (state.subjects.indexOf("math") !== -1 && BANK[state.grade]) {
        useFixed();
        el("quiz-feedback").textContent = t("offlineNote");
        return;
      }
      el("loading-text").textContent = t("loadingFailed");
      el("loading-error").textContent = t("aiOffline");
      el("btn-retry").hidden = false;
      return;
    }
    startQuestions(list, "ai");
  }

  function startQuestions(list, source) {
    state.source = source || "builtin";
    state.queue = list;
    state.index = 0;
    state.score = 0;
    state.weakTopics = [];
    show("quiz");
    renderQuestion();
  }

  function beginQuiz() {
    return makeQuiz();
  }

  function useFixed() {
    if (state.subjects.indexOf("math") === -1) return;
    startQuestions(orderFocus(BANK[state.grade]), "builtin");
  }

  function renderQuestion() {
    state.locked = false;
    const list = state.queue;
    const item = list[state.index];
    el("quiz-counter").textContent = fill(t("counter"), state.index + 1);
    el("quiz-progress").style.width = (state.index / list.length) * 100 + "%";
    el("quiz-question").textContent = textFor(item.q);
    el("quiz-feedback").textContent = "";
    el("quiz-feedback").className = "feedback";
    el("btn-next").hidden = true;

    const box = el("quiz-options");
    box.innerHTML = "";
    optsFor(item).forEach(function (text, i) {
      const b = document.createElement("button");
      b.className = "opt";
      b.textContent = text;
      b.addEventListener("click", function () {
        answer(i, item, b);
      });
      box.appendChild(b);
    });
  }

  function answer(picked, item, button) {
    if (state.locked) return;
    state.locked = true;
    const buttons = el("quiz-options").querySelectorAll("button");
    buttons.forEach(function (b, i) {
      b.disabled = true;
      if (i === item.answer) b.classList.add("correct");
    });
    const fb = el("quiz-feedback");
    if (picked === item.answer) {
      state.score += 1;
      button.classList.add("correct");
      fb.textContent = t("right");
      fb.className = "feedback ok";
    } else {
      button.classList.add("wrong");
      fb.textContent = fill(t("wrong"), optsFor(item)[item.answer]);
      fb.className = "feedback no";
      if (!state.weakTopics.some(function (topic) { return topic.en === item.topic.en; })) {
        state.weakTopics.push(item.topic);
      }
    }
    el("btn-next").hidden = false;
  }

  function nextQuestion() {
    state.index += 1;
    if (state.index >= state.queue.length) {
      finishQuiz({
        passed: state.score >= 8,
        score: state.score,
        total: state.queue.length,
        subject: state.subjects.join("+") || "math",
        grade: state.grade,
        weakTopics: state.weakTopics.map(function (topic) { return topic.en; }),
        source: state.source
      });
      return;
    }
    renderQuestion();
  }

  window.finishQuiz = function (result) {
    el("quiz-progress").style.width = "100%";
    el("score-label").textContent = t("scoreLabel");
    el("score-value").textContent = result.score + " / " + result.total;
    el("score-text").textContent = fill(t("scoreText"), result.score);
    const verdict = el("score-verdict");
    verdict.textContent = result.passed ? t("passed") : t("failed");
    verdict.className = "verdict " + (result.passed ? "ok" : "no");
    const weak = el("score-weak");
    const names = result.weakTopics.map(topicLabel);
    weak.textContent = names.length ? fill(t("weak"), names.join(", ")) : "";
    show("score");
    saveForExtension(result);
    if (!result.passed) watchRetry();
  };

  function saveForExtension(result) {
    const payload = {
      passed: result.passed,
      score: result.score,
      total: result.total,
      subject: result.subject,
      source: result.source,
      grade: result.grade,
      weakTopics: result.weakTopics,
      at: Date.now()
    };
    try {
      localStorage.setItem("lastQuiz", JSON.stringify(payload));
    } catch (error) {
      console.warn("Cure Brainrot: cannot save the last quiz", error.message);
    }
    if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) return;
    chrome.storage.local.set({ lastQuiz: payload }).catch(function (error) {
      console.warn("Cure Brainrot: could not save the quiz result", error.message);
    });
  }

  function refreshMenu() {
    el("menu-title").textContent = t("settings");
    el("menu-lang-label").textContent = t("language");
    el("menu-grade-label").textContent = t("gradeWord");
    el("menu-sub-label").textContent = t("subjects");
    el("add-go").textContent = t("add");
    el("add-name").placeholder = t("subjectName");
    el("btn-menu-close").textContent = t("close");
    Array.from(el("menu-lang").children).forEach(function (chip) {
      chip.classList.toggle("on", chip.dataset.code === state.lang);
    });
    Array.from(el("menu-grade").children).forEach(function (chip) {
      chip.classList.toggle("on", Number(chip.dataset.code) === state.grade);
    });
    if (el("chip-add")) el("chip-add").textContent = "+ " + t("addSubject");
    Array.from(el("menu-subjects").children).forEach(function (chip) {
      if (!chip.dataset.code) return;
      chip.textContent = subName(chip.dataset.code);
      chip.classList.toggle("on", state.subjects.indexOf(chip.dataset.code) !== -1);
    });
  }

  function buildMenu() {
    [["en", "English"], ["ru", "Русский"], ["kk", "Қазақша"]].forEach(function (pair) {
      const b = document.createElement("button");
      b.className = "chip";
      b.dataset.code = pair[0];
      b.textContent = pair[1];
      b.addEventListener("click", function () {
        state.lang = pair[0];
        afterSettingsChange(true);
      });
      el("menu-lang").appendChild(b);
    });
    [5, 6, 7].forEach(function (grade) {
      const b = document.createElement("button");
      b.className = "chip";
      b.dataset.code = String(grade);
      b.textContent = String(grade);
      b.addEventListener("click", function () {
        state.grade = grade;
        afterSettingsChange(true);
      });
      el("menu-grade").appendChild(b);
    });
  }

  function buildSubjects() {
    el("menu-subjects").innerHTML = "";
    allSubjects().forEach(function (sub) {
      const b = document.createElement("button");
      b.className = "chip";
      b.dataset.code = sub;
      b.textContent = subName(sub);
      b.addEventListener("click", function () {
        toggleSubject(sub);
        buildSubjects();
        afterSettingsChange(true);
      });
      el("menu-subjects").appendChild(b);
    });
    const add = document.createElement("button");
    add.className = "chip";
    add.id = "chip-add";
    add.textContent = "+ " + t("addSubject");
    add.addEventListener("click", function () {
      el("menu-add").hidden = !el("menu-add").hidden;
      el("menu-status").textContent = "";
      if (!el("menu-add").hidden) el("add-name").focus();
    });
    el("menu-subjects").appendChild(add);
  }

  async function makeTopics(name) {
    const API = LLM;
    const prompt = "School subject: " + name + ". Write 6 short topics for each grade: 5, 6, 7. " +
      "Each topic: a short English key (2-4 words) plus its Russian and Kazakh translation. " +
      'JSON only, no text outside: {"5":[{"en":"","ru":"","kk":""}],"6":[],"7":[]}';
    const r = await fetch(API + "/chat/completions", {
      method: "POST",
      headers: headers(await storedKey()),
      body: JSON.stringify({ model: "dsv41", temperature: 0.7, messages: [{ role: "user", content: prompt }] })
    });
    if (!r.ok) {
      const body = (await r.text()).slice(0, 200);
      throw new Error("AI server " + r.status + ": " + body);
    }
    const data = await r.json();
    const raw = data.choices[0].message.content.trim().replace(/^```(?:json)?/, "").replace(/```$/, "");
    const start = raw.indexOf("{");
    const end = raw.lastIndexOf("}");
    if (start === -1 || end === -1) throw new Error("AI answer is not JSON: " + raw.slice(0, 200));
    const json = JSON.parse(raw.slice(start, end + 1));
    const topics = {};
    [5, 6, 7].forEach(function (grade) {
      const list = json[grade] || json[String(grade)];
      if (!Array.isArray(list)) throw new Error("no topics for grade " + grade);
      const good = list.filter(function (topic) {
        return topic && typeof topic.en === "string" && topic.en.trim() &&
          typeof topic.ru === "string" && topic.ru.trim() &&
          typeof topic.kk === "string" && topic.kk.trim();
      }).slice(0, 8);
      if (good.length < 4) throw new Error("only " + good.length + " topics for grade " + grade);
      topics[grade] = good.map(function (topic) {
        return { en: topic.en.trim(), ru: topic.ru.trim(), kk: topic.kk.trim() };
      });
    });
    return topics;
  }

  async function addCustomSubject() {
    const input = el("add-name");
    const name = input.value.trim();
    if (name.length < 2) {
      el("menu-status").textContent = t("subjectName") + "?";
      return;
    }
    el("add-go").disabled = true;
    el("menu-status").textContent = t("makingTopics");
    try {
      const topics = await makeTopics(name);
      const id = "c" + Date.now().toString(36);
      state.custom.push({ id: id, name: name, topics: topics });
      registerCustomTopics();
      state.subjects.push(id);
      saveSettings();
      buildSubjects();
      refreshMenu();
      el("menu-add").hidden = true;
      input.value = "";
      el("menu-status").textContent = "";
      afterSettingsChange(true);
    } catch (error) {
      console.warn("Cure Brainrot: cannot make topics", error);
      el("menu-status").textContent = t("topicsFailed") + " " + error.message;
    }
    el("add-go").disabled = false;
  }

  function afterSettingsChange(keepMenuOpen) {
    saveSettings();
    applyLanguage();
    if (!keepMenuOpen) el("menu").hidden = true;
    if (["loading", "quiz", "focus"].indexOf(state.screen) !== -1) startQuiz(state.grade);
  }

  let retryTimer = 0;

  function retryLeft() {
    if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) return Promise.resolve(0);
    return chrome.storage.local.get("cureBrainrot").then(function (stored) {
      const saved = stored && stored.cureBrainrot;
      return saved && saved.retryAfter ? Math.max(0, saved.retryAfter - Date.now()) : 0;
    }).catch(function () { return 0; });
  }

  function clockText(ms) {
    const total = Math.max(0, Math.ceil(ms / 1000));
    return Math.floor(total / 60) + ":" + String(total % 60).padStart(2, "0");
  }

  function paintRetry(left) {
    const blocked = left > 0;
    const line = blocked ? fill(t("retryWait"), clockText(left)) : "";
    ["retry-note", "score-note"].forEach(function (id) {
      const node = el(id);
      if (!node) return;
      node.textContent = line;
      node.hidden = !blocked;
    });
    ["btn-yes", "btn-reopen", "btn-again"].forEach(function (id) {
      const button = el(id);
      if (button) button.disabled = blocked;
    });
    return blocked;
  }

  function watchRetry() {
    clearInterval(retryTimer);
    retryLeft().then(function (left) {
      if (!paintRetry(left)) return;
      retryTimer = setInterval(function () {
        retryLeft().then(function (nowLeft) {
          if (!paintRetry(nowLeft)) clearInterval(retryTimer);
        });
      }, 1000);
    });
  }

  function openQuiz() {
    if (el("btn-yes").disabled) return;
    if (state.hasSettings) {
      startQuiz(state.grade);
      return;
    }
    renderSetup("lang");
    show("setup");
  }

  el("btn-menu").addEventListener("click", function () {
    el("menu").hidden = !el("menu").hidden;
    refreshMenu();
  });

  el("add-go").addEventListener("click", addCustomSubject);

  el("add-name").addEventListener("keydown", function (event) {
    if (event.key === "Enter") addCustomSubject();
  });

  el("btn-menu-close").addEventListener("click", function () {
    el("menu").hidden = true;
  });

  el("btn-yes").addEventListener("click", openQuiz);

  el("btn-no").addEventListener("click", function () {
    show("closed");
  });

  el("btn-reopen").addEventListener("click", openQuiz);

  el("btn-next").addEventListener("click", nextQuestion);

  el("btn-ok").addEventListener("click", beginQuiz);
  el("btn-retry").addEventListener("click", makeQuiz);
  el("btn-fixed").addEventListener("click", useFixed);

  el("btn-again").addEventListener("click", openQuiz);

  registerCustomTopics();
  buildMenu();
  applyLanguage();
  buildSubjects();
  applyLanguage();
  show("popup");
  watchRetry();
})();
